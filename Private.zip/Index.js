(function() {
    function $(id){ return document.getElementById(id); }

    var card = $('card'),
        openB = $('open'),
        closeB = $('close'),
        celebration = $('celebration'),
        audio = $('audioPlayer');

    // OPEN button click
    openB.addEventListener('click', function(){
        celebration.style.display = 'block';
        audio.play().catch(err => console.log('Autoplay blocked, user interaction needed.'));
    });

    // CLOSE button click
    closeB.addEventListener('click', function(){
        celebration.style.display = 'none';
        audio.pause();
        audio.currentTime = 0;
    });

}());